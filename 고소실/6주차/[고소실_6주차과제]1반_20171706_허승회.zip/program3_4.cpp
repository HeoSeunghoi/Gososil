#include "my_solver.h"

#define index_2d(row, col, dim) row*dim+col

float error(float* a, float* x, float* b, int* n) {
	int i, j;
	float m_abs = 0, b_abs = 0;
	float m[32];
	int poi;
	for (i = 0; i < *n; i++) {
		m[i] = 0;
		for (j = 0; j < *n; j++) {
			poi = j * (*n) + i;
			m[i] += a[index_2d(j, i, *n)] * x[j];
		}
		m[i] -= b[i];
	}

	for (i = 0; i < *n; i++) {
		m_abs += pow(m[i], 2);
		b_abs += pow(b[i], 2);
	}
	return m_abs / b_abs;
}

void homework4() {
	int i, ia, j, n, l[32];
	float a[32 * 32], save_a[32 * 32];
	float b[32], save_b[32], x[32], s[32];
	float e;

	FILE* fp_r = fopen("linear_system_3-4.txt", "r");
	if (fp_r == NULL) {
		printf("%s file open error...\n", "linear_system_3-4.txt");
		return;
	}

	FILE* fp_w = fopen("solution_3-4.txt", "w");
	if (fp_r == NULL) {
		printf("%s file open error...\n", "solution_3-4.txt");
		return;
	}

	fscanf(fp_r, "%d", &n);
	fprintf(fp_w, "%d\n", n);
	ia = n;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			fscanf(fp_r, "%f", &a[index_2d(j, i, n)]);
			save_a[index_2d(j, i, n)] = a[index_2d(j, i, n)];
		}
	}

	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%f", &b[i]);
		save_b[i] = b[i];
	}

	gespp_(&n, a, &ia, l, s);
	solve_(&n, a, &ia, l, b, x);

	for (i = 0; i < n; i++)
		fprintf(fp_w, "%.6f\n", x[i]);
	printf("\n");
	e = error(save_a, x, save_b, &n);
	fprintf(fp_w, "%.6f\n", e);
	fclose(fp_r);
	fclose(fp_w);
}