#include "my_solver.h"

#define SOLNUMS 4
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

double C, b;
double p0[3], p1[3], p2[3], p3[3];
double t[4], tr[4];

void f_h1_1(int* n, double* x, double* fvec, double* fjac, int* ldfjac, int* iflag)
{
	if (*iflag == 1) {
		fvec[0] = (x[0] - p0[0]) * (x[0] - p0[0]) + (x[1] - p0[1]) * (x[1] - p0[1]) + (x[2] - p0[2]) * (x[2] - p0[2]) - (C * (tr[0] + x[3] - t[0])) * (C * (tr[0] + x[3] - t[0]));
		fvec[1] = (x[0] - p1[0]) * (x[0] - p1[0]) + (x[1] - p1[1]) * (x[1] - p1[1]) + (x[2] - p1[2]) * (x[2] - p1[2]) - (C * (tr[1] + x[3] - t[1])) * (C * (tr[1] + x[3] - t[1]));
		fvec[2] = (x[0] - p2[0]) * (x[0] - p2[0]) + (x[1] - p2[1]) * (x[1] - p2[1]) + (x[2] - p2[2]) * (x[2] - p2[2]) - (C * (tr[2] + x[3] - t[2])) * (C * (tr[2] + x[3] - t[2]));
		fvec[3] = (x[0] - p3[0]) * (x[0] - p3[0]) + (x[1] - p3[1]) * (x[1] - p3[1]) + (x[2] - p3[2]) * (x[2] - p3[2]) - (C * (tr[3] + x[3] - t[3])) * (C * (tr[3] + x[3] - t[3]));

	}
	else if (*iflag == 2)
	{
		fjac[0] = 2.0 * (x[0] - p0[0]);	fjac[4] = 2.0 * (x[1] - p0[1]);	fjac[8] = 2.0 * (x[2] - p0[2]);	fjac[12] = -2.0 * C * C * (tr[0] + x[3] - t[0]);
		fjac[1] = 2.0 * (x[0] - p1[0]);	fjac[5] = 2.0 * (x[1] - p1[1]);	fjac[9] = 2.0 * (x[2] - p1[2]);	fjac[13] = -2.0 * C * C * (tr[1] + x[3] - t[1]);
		fjac[2] = 2.0 * (x[0] - p2[0]);	fjac[6] = 2.0 * (x[1] - p2[1]);	fjac[10] = 2.0 * (x[2] - p2[2]);	fjac[14] = -2.0 * C * C * (tr[2] + x[3] - t[2]);
		fjac[3] = 2.0 * (x[0] - p3[0]);	fjac[7] = 2.0 * (x[1] - p3[1]);	fjac[11] = 2.0 * (x[2] - p3[2]);	fjac[15] = -2.0 * C * C * (tr[3] + x[3] - t[3]);
	}
}

void f_h1_2(int* n, double* x, double* fvec, int* iflag)
{
	fvec[0] = (x[0] - p0[0]) * (x[0] - p0[0]) + (x[1] - p0[1]) * (x[1] - p0[1]) + (x[2] - p0[2]) * (x[2] - p0[2]) - (C * (tr[0] + x[3] - t[0])) * (C * (tr[0] + x[3] - t[0]));
	fvec[1] = (x[0] - p1[0]) * (x[0] - p1[0]) + (x[1] - p1[1]) * (x[1] - p1[1]) + (x[2] - p1[2]) * (x[2] - p1[2]) - (C * (tr[1] + x[3] - t[1])) * (C * (tr[1] + x[3] - t[1]));
	fvec[2] = (x[0] - p2[0]) * (x[0] - p2[0]) + (x[1] - p2[1]) * (x[1] - p2[1]) + (x[2] - p2[2]) * (x[2] - p2[2]) - (C * (tr[2] + x[3] - t[2])) * (C * (tr[2] + x[3] - t[2]));
	fvec[3] = (x[0] - p3[0]) * (x[0] - p3[0]) + (x[1] - p3[1]) * (x[1] - p3[1]) + (x[2] - p3[2]) * (x[2] - p3[2]) - (C * (tr[3] + x[3] - t[3])) * (C * (tr[3] + x[3] - t[3]));
}

void homework1_1() {
	int n = SOLNUMS;
	double x[SOLNUMS] = { 1, 1, 1 };	//need to initilize x0
	double fvec[SOLNUMS], fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (SOLNUMS + 13)) / 2;

	int i, j;
	char readfile[256];
	char writefile[256];

	FILE* fp_r;
	FILE* fp_w;

	for (i = 0; i < 3; i++) {
		sprintf(readfile, "GPS_signal_%d.txt", i);
		sprintf(writefile, "GPS_position_3-1_%d.txt", i);

		fp_r = fopen(readfile, "r");
		if (fp_r == NULL){
			printf("%s file open error...\n", readfile);
			return;
		}
		fp_w = fopen(writefile, "w");
		if (fp_w == NULL){
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%lf %lf", &C, &b);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p0[0], &p0[1], &p0[2], &t[0], &tr[0]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p1[0], &p1[1], &p1[2], &t[1], &tr[1]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p2[0], &p2[1], &p2[2], &t[2], &tr[2]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p3[0], &p3[1], &p3[2], &t[3], &tr[3]);

		printf("Enter Initial Value x : ");
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b;

		hybrj1_(f_h1_1, &n, x, fvec, fjac, &ldfjac, &tol, &info, wa, &lwa);

		fprintf(fp_w, "Solution\n");
		for (j = 0; j < 4; j++)
			fprintf(fp_w, "%lf\n", x[j]);
		fprintf(fp_w, "=======================\nfvec\n");
		for (j = 0; j < 4; j++)
			fprintf(fp_w, "%lf\n", fvec[j]);
		fclose(fp_r);
		fclose(fp_w);
	}
}

void homework1_2() {
	int n = SOLNUMS;
	double x[SOLNUMS] = { 1, 1, 1 };	//need to initilize x0
	double fvec[SOLNUMS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;

	int i, j;
	char readfile[256];
	char writefile[256];

	FILE* fp_r;
	FILE* fp_w;

	for (int i = 0; i < 3; i++)
	{
		sprintf(readfile, "GPS_signal_%d.txt", i);
		sprintf(writefile, "GPS_position_3-2_%d.txt", i);

		fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}
		fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%lf %lf", &C, &b);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p0[0], &p0[1], &p0[2], &t[0], &tr[0]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p1[0], &p1[1], &p1[2], &t[1], &tr[1]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p2[0], &p2[1], &p2[2], &t[2], &tr[2]);
		fscanf(fp_r, "%lf %lf %lf %lf %lf", &p3[0], &p3[1], &p3[2], &t[3], &tr[3]);

		printf("Enter Initial Value x : ");
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b;
		hybrd1_(f_h1_2, &n, x, fvec, &tol, &info, wa, &lwa);

		fprintf(fp_w, "Solution\n");
		for (j = 0; j < 4; j++)
			fprintf(fp_w, "%lf\n", x[j]);
		fprintf(fp_w, "=======================\nfvec\n");
		for (j = 0; j < 4; j++)
			fprintf(fp_w, "%lf\n", fvec[j]);

		fclose(fp_r);
		fclose(fp_w);
	}
}