#include "my_solver.h"

void program2_1()
{
	FILE* fp_r, * fp_w;
	__int64 start, freq, end;
	float resultTime = 0;

	fp_r = fopen("sampling_table.txt", "r");
	if (fp_r == NULL) {
		printf("input file not found....\n");
		exit(0);
	}

	fp_w = fopen("pdf_table.txt", "w");

	/***************************************************/
	int i;
	double n, h;
	double** arr;
	double sum = 0, sum0 = 0, sum1 = 0, sum2 = 0, sum3 = 0, tmp1 = 0, tmp2 = 0;
	double interval = 0;

	fscanf(fp_r, "%lf %lf", &n, &h);

	arr = (double**)malloc(sizeof(double*) * n);
	for (i = 0; i < n; i++)
		arr[i] = (double*)malloc(sizeof(double) * 2);

	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf", &arr[i][0], &arr[i][1]);

	interval = 1 / (n - 1);
	for (i = 0; i < n; i++)
		arr[i][0] = interval * i;

	for (i = 0; i < n - 1; i++)
		sum += interval * (arr[i][1] + arr[i + 1][1]) / 2;

	for (i = 0; i < n; i++)
		arr[i][1] = arr[i][1] / sum;

	sum = 0;
	for (i = 0; i < n - 1; i++)
		sum += interval * (arr[i][1] + arr[i + 1][1]) / 2;

	fprintf(fp_w, "%.0lf %lf\n", n, interval);
	for (i = 0; i < n; i++)
		fprintf(fp_w, "%.6lf %.6lf\n", arr[i][0], arr[i][1]);

	for (i = 0; i < n - 1; i++) {
		if (arr[i][0] < 0.25) {
			if (arr[i + 1][0] > 0.25) {
				tmp1 = interval * (arr[i][1] + arr[i + 1][1]) / 2;
				tmp2 = (0.25 - arr[i][0]) * (arr[i][1] + (arr[i + 1][1] - arr[i][1]) / (arr[i + 1][0] - arr[i][0]) * (0.25 - arr[i][0]) / 2);

				sum0 += tmp2;
				sum1 += (tmp1 - tmp2);
			}
			else
				sum0 += interval * (arr[i][1] + arr[i + 1][1]) / 2;
		}
		else if (arr[i][0] < 0.5) {
			if (arr[i + 1][0] > 0.5) {
				tmp1 = interval * (arr[i][1] + arr[i + 1][1]) / 2;
				tmp2 = (0.5 - arr[i][0]) * (arr[i][1] + (arr[i + 1][1] - arr[i][1]) / (arr[i + 1][0] - arr[i][0]) * (0.5 - arr[i][0]) / 2);

				sum1 += tmp2;
				sum2 += tmp1 - tmp2;
			}
			else 
				sum1 += interval * (arr[i][1] + arr[i + 1][1]) / 2;
		}
		else if (arr[i][0] < 0.75) {
			if (arr[i + 1][0] > 0.75) {
				tmp1 = interval * (arr[i][1] + arr[i + 1][1]) / 2;
				tmp2 = (0.75 - arr[i][0]) * (arr[i][1] + (arr[i + 1][1] - arr[i][1]) / (arr[i + 1][0] - arr[i][0]) * (0.75 - arr[i][0]) / 2);

				sum2 += tmp2;
				sum3 += tmp1 - tmp2;
			}
			else 
				sum2 += interval * (arr[i][1] + arr[i + 1][1]) / 2;
		}
		else
			sum3 += interval * (arr[i][1] + arr[i + 1][1]) / 2;
	}

	printf("*** Integrating the pdf from 0.0 to 1.0 =  %.15lf\n", sum);
	printf("*** Integrating the pdf from 0.0 to 0.25 =  %.15lf\n", sum0);
	printf("*** Integrating the pdf from 0.25 to 0.5 =  %.15lf\n", sum1);
	printf("*** Integrating the pdf from 0.5 to 0.75 =  %.15lf\n", sum2);
	printf("*** Integrating the pdf from 0.75 to 0.1 =  %.15lf\n", sum3);

	for (i = 0; i < n; i++)
		free(arr[i]);
	free(arr);
	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
