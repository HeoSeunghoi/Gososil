#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

double** arr;
double n;
double interval;
double randN;

double f1(double x);
double integ(double x);
double bisection(double a0, double b0);

double f1(double x) {
	double ans;
	ans = integ(x) - randN;
	return ans;
}

double integ(double x) {
	double result = 0, tmp;
	int i;

	for (i = 0; i < n - 1; i++) {
		if (arr[i][0] < x) {
			if (arr[i + 1][0] > x) {
				tmp = (x - arr[i][0]) * (arr[i][1] + (arr[i + 1][1] - arr[i][1]) / (arr[i + 1][0] - arr[i][0]) * (x - arr[i][0]) / 2);
				result += tmp;
				break;
			}
			else
				result += interval * (arr[i][1] + arr[i + 1][1]) / 2;
		}
	}
	return result;
}

double bisection(double a0, double b0) {
	double x0, tmp;
	int n;
	double esp, check;
	for (n = 0; n < Nmax; n++) {
		x0 = (a0 + b0) / 2;
		tmp = a0 + (b0 - a0) / 2;
		esp = (a0 - b0) / 2;
		if (fabs(f1(tmp)) < DELTA || fabs(esp) < EPSILON) {
			n++;
			break;
		}
		check = f1(a0) * f1(x0);
		if (check < 0)
			b0 = tmp;
		else
			a0 = tmp;
	}
	return x0;
}

void program2_2()
{
	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int i = 0, nr;
	int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0;
	double result;
	unsigned int iseed = (unsigned int)time(NULL);
	srand(iseed);
	// arr�� ������ ����
	fscanf(fp_r, "%lf %lf", &n, &interval);

	arr = (double**)malloc(sizeof(double*) * n);
	for (i = 0; i < n; i++)
		arr[i] = (double*)malloc(sizeof(double) * 2);
	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf", &arr[i][0], &arr[i][1]);
	printf("Enter Random Number Count : ");
	scanf("%d", &nr);
	fprintf(fp_w, "%d\n", nr);
	for (i = 0; i < nr; i++) {
		randN = rand() / 32767.0;
		if (randN == 0) {
			i--;
			continue;
		}

		result = bisection(0.0, 1.0);
		fprintf(fp_w, "%.15lf\n", result);
	}
	/***************************************************/
	for (i = 0; i < n; i++)
		free(arr[i]);
	free(arr);
	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
