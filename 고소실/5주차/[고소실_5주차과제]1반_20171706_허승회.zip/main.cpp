﻿#include "my_solver.h"

int main() {
    program2_1(); // make pdf table
    program2_2(); // create random number
    //program_exp();
    program2_3(); // HOMEWORK
}
