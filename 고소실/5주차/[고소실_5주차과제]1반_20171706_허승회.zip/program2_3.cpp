#include "my_solver.h"
#include<math.h>
#include<time.h>
#include<stdlib.h>

double f0(double x);
double fp0(double x);
double f3_1(double x);
double f3_2(double x);
double f3_3(double x);
double secant(double x0, double x1);
double newton(double x0);
extern double integ(double x);
extern double bisection(double a0, double b0);

int rn;
double (*f)(double);
double (*fp)(double);
double* hist;
double max[2], x, y;
double* rand_arr;
extern double** arr;
extern double randN;
extern double interval;
extern double n;

double test(double x) {
	double ans;
	ans = integ(x) - max[0];
	return ans;
}

double f0(double x) {
	double ans;
	ans = integ(x) - randN;
	return ans;
}

double fp0(double x) {
	int i;
	double ans, s;
	for (i = 0; i < n - 1; i++)
		if (arr[i + 1][0] > x)
			break;
	if (i == n - 1)
		i--;
	s = (x - arr[i][0]) / (arr[i + 1][0] - arr[i][0]);
	ans = (1 - s) * arr[i][1] + s * arr[i + 1][1];
	return ans;
}

double f3_1(double x) {
	double ans;
	ans = (1 - exp(-2 * x)) - randN;
	return ans;
}

double f3_2(double x) {
	double ans;
	ans = (1 - exp(-3 * x)) - randN;
	return ans;
}

double f3_3(double x) {
	double ans;
	ans = (1 - exp(-7 * x)) - randN;
	return ans;
}

double secant(double x0, double x1) {
	double temp;
	int n;
	double esp;

	for (n = 0; n < Nmax; n++) {
		temp = x1 - f(x1) * ((x1 - x0) / (f(x1) - f(x0)));
		esp = x1 - x0;
		if (fabs(f(x0)) < DELTA || fabs(esp) < EPSILON) {
			x0 = x1;
			n++;
			break;
		}
		x0 = x1;
		x1 = temp;
	}
	return x0;
}

double newton(double x0) {
	double x1;
	int n;
	double esp;

	for (n = 0; n < Nmax; n++) {
		x1 = x0 - f(x0) / fp(x0);
		esp = x1 - x0;
		if (fabs(f(x0)) < DELTA || fabs(esp) < EPSILON) {
			x0 = x1;
			n++;
			break;
		}
		x0 = x1;
	}
	return x0;
}

void program_exp() {
	int i = 0, rn;
	double result1 = 0, result2 = 0, result3 = 0, tmp;
	double result4 = 0, result5 = 0, result6 = 0;
	double My_mean, Real_mean, My_var, Real_var;
	unsigned int iseed = (unsigned int)time(NULL);
	srand(iseed);
	printf("Enter Random Number Count : ");
	scanf("%d", &rn);
	for (i = 0; i < rn; i++) {
		randN = rand() / 32767.0;
		if (randN == 0 || randN > 0.999999) {
			i--;
			continue;
		}
		f = f3_1;
		tmp = -(log(1 - randN)) / 2;
		result1 += tmp;
		result4 += pow(tmp - (1 / 2.0), 2);

		f = f3_2;
		tmp = -(log(1 - randN)) / 3;
		result2 += tmp;
		result5 += pow(tmp - (1 / 3.0), 2);

		f = f3_3;
		tmp = -(log(1 - randN)) / 7;
		result3 += tmp;
		result6 += pow(tmp - (1 / 7.0), 2);
	}
	My_mean = result1 / rn;
	Real_mean = 1 / 2.0;
	My_var = result4 / (rn);
	Real_var = 1 / (pow(2.0, 2));
	printf("========My mean=================Real mean=======\n");
	printf("%.15e |||| %.15e\n", My_mean, Real_mean);
	printf("%.15e |||| %.15e\n", My_var, Real_var);
	printf("====================Lamda : 2===================\n");
	My_mean = result2 / rn;
	Real_mean = 1 / 3.0;
	My_var = result5 / (rn);
	Real_var = 1 / (pow(3.0, 2));
	printf("%.15e |||| %.15e\n", My_mean, Real_mean);
	printf("%.15e |||| %.15e\n", My_var, Real_var);
	printf("====================Lamda : 3===================\n");

	My_mean = result3 / rn;
	Real_mean = 1 / 7.0;
	My_var = result6 / (rn);
	Real_var = 1 / (pow(7.0, 2));
	printf("%.15e |||| %.15e\n", My_mean, Real_mean);
	printf("%.15e |||| %.15e\n", My_var, Real_var);
	printf("====================Lamda : 7===================\n");
}

void write_data(FILE* fp, int* cnt) {
	fprintf(fp, "%d\n", cnt[0]);
	fprintf(fp, "%d\n", cnt[1]);
	fprintf(fp, "%d\n", cnt[2]);
	fprintf(fp, "%d\n", cnt[3]);
	fprintf(fp, "%d\n", cnt[4]);
	fprintf(fp, "%d\n", cnt[5]);
	fprintf(fp, "%d\n", cnt[6]);
	fprintf(fp, "%d\n", cnt[7]);
	fprintf(fp, "%d\n", cnt[8]);
	fprintf(fp, "%d\n", cnt[9]);
}

// HOMEWORK
void program2_3()
{
	int cnt[10], i;
	FILE* fp_r, *fp_r1, * fp_h;
	fp_r = fopen("pdf_table.txt", "r");
	fp_h = fopen("histogram.txt", "w");
	for (i = 0; i < 10; i++)
		cnt[i] = 0;

	unsigned int iseed = (unsigned int)time(NULL);
	srand(iseed);

	fscanf(fp_r, "%lf %lf", &n, &interval);

	max[0] = 0.0, max[1] = 0.0;

	arr = (double**)malloc(sizeof(double*) * n);
	for (i = 0; i < n; i++)
		arr[i] = (double*)malloc(sizeof(double) * 2);
	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%lf %lf", &arr[i][0], &arr[i][1]);
		if (arr[i][1] > max[1]) {
			max[0] = arr[i][0];
			max[1] = arr[i][1];
		}
	}



	f = f0;
	fp = fp0;
	printf("Enter Random Number Count : ");
	scanf("%d", &rn);

	program2_2_a();

	fp_r1 = fopen("random_event_table.txt", "r");
	hist = (double*)malloc(sizeof(double) * rn);
	for (i = 0; i < rn; i++)
		fscanf(fp_r1, "%lf", &hist[i]);
	fclose(fp_r1);

	for (i = 0; i < rn; i++) {
		if (hist[i] < 0.1) cnt[0]++;
		else if (hist[i] < 0.2) cnt[1]++;
		else if (hist[i] < 0.3) cnt[2]++;
		else if (hist[i] < 0.4) cnt[3]++;
		else if (hist[i] < 0.5) cnt[4]++;
		else if (hist[i] < 0.6) cnt[5]++;
		else if (hist[i] < 0.7) cnt[6]++;
		else if (hist[i] < 0.8) cnt[7]++;
		else if (hist[i] < 0.9) cnt[8]++;
		else if (hist[i] <= 1.0) cnt[9]++;
	}
	write_data(fp_h, cnt);

	for (i = 0; i < 10; i++)
		cnt[i] = 0;

	printf("Enter Random Number Count : ");
	scanf("%d", &rn);

	program2_2_b();

	fp_r1 = fopen("random_event_table.txt", "r");
	fscanf(fp_r1, "%d", &rn);
	for (i = 0; i < rn; i++)
		fscanf(fp_r1, "%lf", &hist[i]);
	fclose(fp_r1);

	for (i = 0; i < rn; i++) {
		if (hist[i] < 0.1) cnt[0]++;
		else if (hist[i] < 0.2) cnt[1]++;
		else if (hist[i] < 0.3) cnt[2]++;
		else if (hist[i] < 0.4) cnt[3]++;
		else if (hist[i] < 0.5) cnt[4]++;
		else if (hist[i] < 0.6) cnt[5]++;
		else if (hist[i] < 0.7) cnt[6]++;
		else if (hist[i] < 0.8) cnt[7]++;
		else if (hist[i] < 0.9) cnt[8]++;
		else if (hist[i] <= 1.0) cnt[9]++;
	}
	write_data(fp_h, cnt);

	for (i = 0; i < 10; i++)
		cnt[i] = 0;

	printf("Enter Random Number Count : ");
	scanf("%d", &rn);

	program2_2_c();

	fp_r1 = fopen("random_event_table.txt", "r");
	fscanf(fp_r1, "%d", &rn);
	for (i = 0; i < rn; i++)
		fscanf(fp_r1, "%lf", &hist[i]);
	fclose(fp_r1);

	for (i = 0; i < rn; i++) {
		if (hist[i] < 0.1) cnt[0]++;
		else if (hist[i] < 0.2) cnt[1]++;
		else if (hist[i] < 0.3) cnt[2]++;
		else if (hist[i] < 0.4) cnt[3]++;
		else if (hist[i] < 0.5) cnt[4]++;
		else if (hist[i] < 0.6) cnt[5]++;
		else if (hist[i] < 0.7) cnt[6]++;
		else if (hist[i] < 0.8) cnt[7]++;
		else if (hist[i] < 0.9) cnt[8]++;
		else if (hist[i] <= 1.0) cnt[9]++;
	}
	write_data(fp_h, cnt);

	if (fp_r != NULL) fclose(fp_r);
	if (fp_h != NULL) fclose(fp_h);

	for (i = 0; i < n; i++)
		free(arr[i]);
	free(arr);

	free(hist);
}

// HOMEWORK
void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;
	int i = 0;
	CHECK_TIME_START;
	FILE* fp_w;
	fp_w = fopen("random_event_table.txt", "w");
	fprintf(fp_w, "%d\n", rn);
	// some	thing to do...
	for (i = 0; i < rn; i++) {
		randN = (double)rand() / RAND_MAX;
		if (randN == 0 || randN > 0.999999) {
			i--;
			continue;
		}
		fprintf(fp_w, "%.15lf\n", bisection(0.0, 1.0));
	}

	CHECK_TIME_END(resultTime);
	fclose(fp_w);
	printf("The program2_2_a run time is %f(ms)..\n", resultTime * 1000.0);
}

void program2_2_b()
{
	__int64 start, freq, end;
	float resultTime = 0;

	int i;
	double tmp, check;
	FILE* fp_w;
	fp_w = fopen("random_event_table.txt", "w");
	fprintf(fp_w, "%d\n", rn);

	CHECK_TIME_START;

	// something to do...
	x = 0.0, y = 1.0;
	for (i = 0; i < 4; i++) {
		tmp = x + (y - x) / 2;
		check = test(x) * test(tmp);
		if (check < 0)
			y = tmp;
		else
			x = tmp;
	}
	for (i = 0; i < rn; i++) {
		randN = (double)rand() / RAND_MAX;
		if (randN == 0 || randN > 0.999999) {
			i--;
			continue;
		}
		fprintf(fp_w, "%.15lf\n", secant(x, y));
	}

	CHECK_TIME_END(resultTime);
	fclose(fp_w);
	printf("The program2_2_b run time is %f(ms)..\n", resultTime * 1000.0);
}

void program2_2_c()
{
	__int64 start, freq, end;
	float resultTime = 0;

	int i = 0;
	double tmp, check;
	FILE* fp_w;
	fp_w = fopen("random_event_table.txt", "w");
	fprintf(fp_w, "%d\n", rn);
	CHECK_TIME_START;

	// something to do...
	x = 0.0, y = 1.0;
	for (i = 0; i < 4; i++) {
		tmp = x + (y - x) / 2;
		check = test(x) * test(tmp);
		if (check < 0)
			y = tmp;
		else
			x = tmp;
	}
	for (i = 0; i < rn; i++) {
		randN = (double)rand() / RAND_MAX;
		if (randN == 0 || randN > 0.999999) {
			i--;
			continue;
		}
		fprintf(fp_w, "%.15lf\n", newton((x + y) / 2));
	}

	CHECK_TIME_END(resultTime);
	fclose(fp_w);
	printf("The program2_2_c run time is %f(ms)..\n", resultTime * 1000.0);
}