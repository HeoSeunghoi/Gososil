#include <stdio.h>
#include <string.h>
#include <random>
#include <time.h>

#include <math.h>
#include <time.h>
#include <Windows.h>

__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;
float compute_time1, compute_time2;


#define MATDIM 1024
#define HW1_N 1000000
double *hw1_x, hw1_E, hw1_var1, hw1_var2;
float hw2_a, hw2_b, hw2_c, hw2_naive_ans[2];
double hw2_pre_ans[2];
float arr[10000];
/* hw1 */
void init_hw1(int fixed);
void hw1_calc_e();
void hw1_calc_var1();
void hw1_calc_var2();
/* hw2 */
void hw2_naive();
void hw2_safe();
float hw2_verify(double x);
/* hw3 */
void init_arr();
float comp_max(float max, float x);
void call_big(struct big big);
void call_big_p(struct big* big);
float recu(float x);
void hw3();
void hw3_0();
void hw3_1();
void hw3_2();
void hw3_3();
void hw3_4();
void hw3_5();
typedef struct big {
	float arr[1000];
	float mat[10][10];
	float num;
};

void main(void)
{
	//srand((unsigned)time(NULL));

	/* hw1 */
	puts("====== hw1 ======");
	init_hw1(1);
	hw1_calc_e();
	CHECK_TIME_START;
	hw1_calc_var1();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw1_calc_var1 = %f ms\n", compute_time);
	printf("hw1_calc_var1 value = %.15f\n", hw1_var1);


	CHECK_TIME_START;
	hw1_calc_var2();
	CHECK_TIME_END(compute_time);
	compute_time2 = compute_time;
	printf("hw1_calc_var2 = %f ms\n", compute_time);
	printf("hw1_calc_var2 value = %.15f\n", hw1_var2);
	puts("");
	
	/* hw2 */
	puts("====== hw2 ======");
	printf("a, b, c : ");
	scanf("%f %f %f", &hw2_a, &hw2_b, &hw2_c);
	hw2_naive();
	hw2_safe();
	printf("naive result    : %.15f, %.15f\n", hw2_naive_ans[0], hw2_naive_ans[1]);
	printf("advanced result : %.15f, %.15f\n", hw2_pre_ans[0], hw2_pre_ans[1]);
	puts("");
	printf("Verifying naive ans    : %.15f, %.15f\n", hw2_verify(hw2_naive_ans[0]), hw2_verify(hw2_naive_ans[1]));
	printf("Verifying advanced ans : %.15f, %.15f\n", hw2_verify(hw2_pre_ans[0]), hw2_verify(hw2_pre_ans[1]));
	puts("");
	/* hw3 */
	//hw3();
}

void init_hw1(int fixed)
{
	double *ptr;
	hw1_x = (double *)malloc(sizeof(double)*HW1_N);

	if (fixed)
	{
		double tmp = HW1_N;
		for (int i = 0; i < HW1_N; i++)
		{
			if( i & 1) 
				tmp -= 0.0001;
			hw1_x[i] = tmp;
		}
	}
	else
	{
		srand((unsigned)time(NULL));
		ptr = hw1_x;
		for (int i = 0; i < HW1_N; i++)
			*ptr++ = ((double)rand() / (double)RAND_MAX) * 2;
	}
}
void hw1_calc_e()
{
	int i;
	double result = 0;
	for (i = 0; i < HW1_N; i++)
		result += hw1_x[i];
	hw1_E = result / HW1_N;
}
void hw1_calc_var1()
{
	int i;
	double result1 = 0, result2 = 0;
	for (i = 0; i < HW1_N; i++) {
		result1 += pow(hw1_x[i], 2);
		result2 += hw1_x[i];
	}
	hw1_var1 = (result1 * HW1_N - pow(result2, 2)) / ((double)HW1_N * (HW1_N - 1));
}
void hw1_calc_var2()
{
	int i;
	double result = 0;
	for (i = 0; i < HW1_N; i++)
		result += pow(hw1_x[i] - hw1_E, 2);
	hw1_var2 = (result / (HW1_N - 1));
}


/* hw2 */
void hw2_naive()
{
	hw2_naive_ans[0] = (-hw2_b + sqrt(pow(hw2_b, 2) -4 * hw2_a * hw2_c)) / (2 * hw2_a);
	hw2_naive_ans[1] = (-hw2_b - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c)) / (2 * hw2_a);
}
void hw2_safe()
{
	if (hw2_b > 0) {
		hw2_pre_ans[0] = (-2.0 * hw2_c) / (hw2_b + sqrt(pow(hw2_b, 2.0) - 4.0 * (double)hw2_a * hw2_c));
		hw2_pre_ans[1] = (-hw2_b - sqrt(pow(hw2_b, 2.0) - 4.0 * (double)hw2_a * hw2_c)) / (2.0 * hw2_a);
	}
	else {
		hw2_pre_ans[0] = (-hw2_b + sqrt(pow(hw2_b, 2) - 4 * (double)hw2_a * hw2_c)) / (2 * hw2_a);
		hw2_pre_ans[1] = (-2 * hw2_c) / (hw2_b - sqrt(pow(hw2_b, 2) - 4 * (double)hw2_a * hw2_c));
	}
}
float hw2_verify(double x)
{
	return (double)hw2_a * x * x + (double)hw2_b*x + (double)hw2_c;
}

void hw3() {
	init_arr();

	CHECK_TIME_START;
	hw3_0();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_0 = %f ms\n", compute_time);

	CHECK_TIME_START;
	hw3_1();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_1 = %f ms\n", compute_time);

	CHECK_TIME_START;
	hw3_2();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_2 = %f ms\n", compute_time);

	CHECK_TIME_START;
	hw3_3();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_3 = %f ms\n", compute_time);

	CHECK_TIME_START;
	hw3_4();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_4 = %f ms\n", compute_time);

	CHECK_TIME_START;
	hw3_5();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw3_5 = %f ms\n", compute_time);
}

void init_arr() {
	srand((unsigned)time(NULL));

	for (int i = 0; i < 10000; i++)
		arr[i] = 10000 - i;
}
float comp_max(float max, float x) {
	if (x > max) return x;
	else return max;
}

void call_big(struct big big) {
	big.num = 9;
}
void call_big_p(struct big* big) {
	big->num = 9;
}

float recu(float x) {
	if (x == 1)
		return x;
	return recu(x - 1) * x;
}

void hw3_0() {//original
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = recu(300);
	for (i = 0; i < 10000; i++) {
		re = re / ((x * x) + x - x * 5);
		max = comp_max(max, arr[i]);
		call_big(big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max);
	}
}
void hw3_1() {//function inlining
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = recu(300);
	for (i = 0; i < 10000; i++) {
		re = re / ((x * x) + x - x * 5);
		if (arr[i] > max) max = arr[i];
		call_big(big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max);
	}
}
void hw3_2() {//��� -> �ݺ���
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = 1;
	for (i = 1; i <= 300; i++)
		re *= i;
	for (i = 0; i < 10000; i++) {
		re = re / ((x * x) + x - x * 5);
		max = comp_max(max, arr[i]);
		call_big(big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max);
	}
}
void hw3_3() {// �����ͷ� ���� ����
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = recu(300);
	for (i = 0; i < 10000; i++) {
		re = re / ((x * x) + x - x * 5);
		max = comp_max(max, arr[i]);
		call_big_p(&big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max);
	}
}
void hw3_4() {//loop �ߴ�
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = recu(300);
	x = ((x * x) + x - x * 5);
	for (i = 0; i < 10000; i++) {
		max = comp_max(max, arr[i]);
		call_big(big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max) break;
	}
}
void hw3_5() {//code motion
	int i;
	float max = 0, x = 10;
	struct big big = { 0, };
	float re = recu(300);
	for (i = 0; i < 10000; i++) {
		re = re / ((x * x) + x - x * 5);
		max = comp_max(max, arr[i]);
		call_big(big);
	}
	for (i = 0; i < 10000; i++) {
		x = i;
		x += i * i;
		if (arr[i] == max);
	}
}