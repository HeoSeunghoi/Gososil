#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Newton-Rapson Method
**********************************************/
void program1_1(FILE* fp) {
	double x0, x1;
	int n;
	double esp;
	if (fp == NULL)
		return;

	scanf("%lf", &x0);

	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	for (n = 0; n < Nmax; n++) {
		x1 = x0 - _f(x0) / _fp(x0);
		fprintf(fp, "%d\t%.15e\t%.15e\n", n, x0, fabs(_f(x0)));
		esp = x1 - x0;
		if (fabs(_f(x0)) < DELTA || fabs(esp) < EPSILON) {
			x0 = x1;
			n++;
			break;
		}
		x0 = x1;
	}
	fprintf(fp, "%d\t%.15e\t%.15e\n", n, x0, fabs(_f(x0)));
}
