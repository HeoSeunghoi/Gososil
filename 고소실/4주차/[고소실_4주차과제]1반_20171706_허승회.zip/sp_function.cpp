#define _USE_MATH_DEFINES
#include <math.h>

float _sp_f_comp(float x) {
	float ans;
	ans = log(x) - 1;
	return ans;
}

float _sp_fp_comp(float x) {
	float ans;
	ans = 1 / x;
	return ans;
}
