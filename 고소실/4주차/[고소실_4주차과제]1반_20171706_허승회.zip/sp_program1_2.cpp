#include "my_solver.h"

extern float (*_sp_f)(float);
extern float (*_sp_fp)(float);

/*********************************************
  Secant Method
**********************************************/
void sp_program1_2(FILE* fp) {
	float x0, x1, temp;
	int n;
	float esp;
	if (fp == NULL)
		return;
	scanf("%f %f", &x0, &x1);

	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	for (n = 0; n < Nmax; n++) {
		temp = x1 - _sp_f(x1) * ((x1 - x0) / (_sp_f(x1) - _sp_f(x0)));
		fprintf(fp, "%d\t%.15e\t%.15e\n", n, x0, fabs(_sp_f(x0)));
		esp = x1 - x0;
		if (fabs(_sp_f(x0)) < DELTA || fabs(esp) < EPSILON) {
			x0 = x1;
			n++;
			break;
		}
		x0 = x1;
		x1 = temp;
	}
	fprintf(fp, "%d\t%.15e\t%.15e\n", n, x0, fabs(_sp_f(x0)));
}
