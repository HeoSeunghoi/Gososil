#define _USE_MATH_DEFINES
#include <math.h>

double _f0(double x) {
	double ans, A, B, C, E;
	int l = 89;
	int h = 49;
	int D = 55;
	double b = 11.5 / 180 * M_PI;
	double X = x / 180 * M_PI;
	A = l * sin(b);
	B = l * cos(b);
	C = (h + 0.5 * D) * sin(b) - 0.5 * D * tan(b);
	E = (h + 0.5 * D) * cos(b) - 0.5 * D;
	ans = A * sin(X) * cos(X) + B * sin(X) * sin(X) - C * cos(X) - E * sin(X);
	return ans;
}

double _fp0(double x) {
	double ans, A, B, C, E;
	int l = 89;
	int h = 49;
	int D = 55;
	double b = 11.5 / 180 * M_PI;
	double X = x / 180 * M_PI;
	A = l * sin(b);
	B = l * cos(b);
	C = (h + 0.5 * D) * sin(b) - 0.5 * D * tan(b);
	E = (h + 0.5 * D) * cos(b) - 0.5 * D;
	ans = -1 * A * sin(X) * sin(X) + A * cos(X) * cos(X) + B * sin(2 * X) + C * sin(X) - E * cos(X);
	return ans;
}

double _f1(double x) {
	double ans;
	ans = pow(x, 2) - 4 * x + 4 - log(x);
	return ans;
}

double _fp1(double x) {
	double ans;
	ans = 2 * x - 4 - 1 / x;
	return ans;
}

double _f2(double x) {
	double ans;
	ans = x + 1 - 2 * sin(M_PI * x);
	return ans;
}

double _fp2(double x) {
	double ans;
	ans = 1 - 2 * M_PI * cos(M_PI * x);
	return ans;
}

double _f3(double x) {
	double ans;
	ans = pow(x, 4) - 11.0 * pow(x, 3) + 42.35 * pow(x, 2) - 66.55 * x + 35.1384;
	return ans;
}

double _fp3(double x) {
	double ans;
	ans = 4 * pow(x, 3) - 33.0 * pow(x, 2) + 84.7 * x - 66.55;
	return ans;
}

double _f_sqrt(double x) {
	return x * x - 2.0;
}

double _fp_sqrt(double x) {
	return 2.0 * x;
}

double _f_vehicle(double x) {
	return 0.0;
}

double _fp_vehicle(double x) {
	return 0.0;
}

double _f_comp(double x) {
	double ans;
	ans = log(x) - 1;
	return ans;
}

double _fp_comp(double x) {
	double ans;
	ans = 1 / x;
	return ans;
}
