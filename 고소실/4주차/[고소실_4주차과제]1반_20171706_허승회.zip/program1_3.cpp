#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double a0, b0, x0, x1 , temp;
	int n;
	double esp, check;

	scanf("%lf %lf", &a0, &b0);

	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	for (n = 0; n < Nmax; n++) {
		x0 = (a0 + b0) / 2;
		x1 = x0 - _f(x0) / _fp(x0);
		fprintf(fp, "%d\t%.15e\t%.15e\n", n, x0, fabs(_f(x0)));
		esp = x1 - x0;
		if (fabs(_f(x0)) < DELTA || fabs(esp) < EPSILON) {
			n++;
			break;
		}
		check = _f(a0) * _f(x0);
		if (check < 0)
			b0 = x0;
		else
			a0 = x0;
	}
	fprintf(fp, "%d\t%.15e\t%.15e\n", n, x1, fabs(_f(x1)));
}